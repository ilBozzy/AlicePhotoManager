"""
Alice – Motore v0.6

"""

import os
import sqlite3
import hashlib
import json
import threading
import subprocess
import sys
import base64
import time
from collections import OrderedDict, deque
from pathlib import Path
from datetime import datetime
import webview
from PIL import Image, ExifTags

import webview
from PIL import Image, ExifTags

# ── PERCORSI ─────────────────────────────────────────────────────────────────
DIR_PATH   = os.path.dirname(os.path.realpath(__file__))
HTML_PATH  = os.path.join(DIR_PATH, 'ui', 'index.html')
DB_PATH    = os.path.join(DIR_PATH, 'alice_archivio.db')
CACHE_PATH = os.path.join(DIR_PATH, '.alice_cache')

os.makedirs(CACHE_PATH, exist_ok=True)

if sys.platform == 'win32':
    import ctypes
    try:
        # Tenta di forzare la consapevolezza DPI per monitor
        ctypes.windll.shcore.SetProcessDpiAwareness(2) 
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════════════
# DATABASE
# ══════════════════════════════════════════════════════════════════════════════
class ArchivioDB:
    def __init__(self, db_file: str): # <-- Assicurati che ci sia il parametro db_file
        self.db_file = db_file
        self._conn = sqlite3.connect(self.db_file, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("PRAGMA cache_size=2000")
        self._lock = threading.Lock()
        self._crea_tabelle()

    def _esegui(self, query: str, parametri: tuple = (), fetch: bool = False):
        with self._lock:
            cursor = self._conn.cursor()
            cursor.execute(query, parametri)
            if fetch:
                return cursor.fetchall()
            self._conn.commit()
            return cursor.rowcount

    def _crea_tabelle(self):
        self._esegui('''
            CREATE TABLE IF NOT EXISTS File (
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                Hash_Univoco TEXT UNIQUE, Nome_File TEXT NOT NULL,
                Percorso_Fisico TEXT NOT NULL, Cartella_Padre TEXT, Estensione TEXT,
                Data_Scatto TEXT, Dimensione_MB REAL, Fotocamera TEXT,
                Metadati_Completi TEXT, Preferito INTEGER DEFAULT 0,
                Sorgente TEXT DEFAULT 'Locale'
            )
        ''')
        self._esegui('''
            CREATE TABLE IF NOT EXISTS Album (
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                Nome TEXT UNIQUE NOT NULL,
                Icona TEXT DEFAULT '📁'
            )
        ''')
        self._esegui('''
            CREATE TABLE IF NOT EXISTS Album_Foto (
                Album_ID INTEGER, Hash_Foto TEXT,
                FOREIGN KEY(Album_ID) REFERENCES Album(ID) ON DELETE CASCADE,
                UNIQUE(Album_ID, Hash_Foto)
            )
        ''')

    # ── CRUD FILE ─────────────────────────────────────────────────────────────
    def conta_file(self) -> int:
        res = self._esegui("SELECT COUNT(*) FROM File", fetch=True)
        return res[0][0] if res else 0

    def inserisci_o_aggiorna_file(self, dati: tuple):
        return self._esegui('''
            INSERT INTO File
                (Hash_Univoco, Nome_File, Percorso_Fisico, Cartella_Padre,
                 Estensione, Data_Scatto, Dimensione_MB, Fotocamera, Metadati_Completi)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(Hash_Univoco) DO UPDATE SET
                Percorso_Fisico = excluded.Percorso_Fisico,
                Cartella_Padre  = excluded.Cartella_Padre
        ''', dati)

    def ottieni_tutte_le_foto(self):
        return self._esegui(
            "SELECT Hash_Univoco, Nome_File, Data_Scatto "
            "FROM File WHERE Estensione IN ('.jpg','.jpeg','.png') "
            "ORDER BY Data_Scatto ASC", fetch=True
        )

    def ottieni_foto_paginata(self, offset: int, limit: int):
        """Paginazione per lo streaming progressivo."""
        return self._esegui(
            "SELECT Hash_Univoco, Nome_File, Data_Scatto "
            "FROM File WHERE Estensione IN ('.jpg','.jpeg','.png') "
            "ORDER BY Data_Scatto ASC LIMIT ? OFFSET ?",
            (limit, offset), fetch=True
        )

    def ottieni_preferiti(self):
        return self._esegui(
            "SELECT Hash_Univoco, Nome_File, Data_Scatto "
            "FROM File WHERE Preferito = 1 ORDER BY Data_Scatto ASC", fetch=True
        )

    def aggiorna_preferito(self, hash_file: str, stato: bool):
        self._esegui(
            "UPDATE File SET Preferito = ? WHERE Hash_Univoco = ?",
            (1 if stato else 0, hash_file)
        )

    def ottieni_percorso_da_hash(self, hash_file: str):
        res = self._esegui(
            "SELECT Percorso_Fisico FROM File WHERE Hash_Univoco = ?",
            (hash_file,), fetch=True
        )
        return res[0][0] if res else None

    def ottieni_cartelle_padre(self):
        return self._esegui("SELECT DISTINCT Cartella_Padre FROM File", fetch=True)

    def ottieni_hash_ordinati(self, offset: int = 0, limit: int = 200):
        return self._esegui(
            "SELECT Hash_Univoco FROM File "
            "WHERE Estensione IN ('.jpg','.jpeg','.png') "
            "ORDER BY Data_Scatto ASC LIMIT ? OFFSET ?",
            (limit, offset), fetch=True
        )

    def conta_foto(self) -> int:
        res = self._esegui(
            "SELECT COUNT(*) FROM File WHERE Estensione IN ('.jpg','.jpeg','.png')",
            fetch=True
        )
        return res[0][0] if res else 0

    # ── ALBUM ──────────────────────────────────────────────────────────────────
    def crea_album(self, nome, icona='📁'):
        try:
            self._esegui("INSERT INTO Album (Nome, Icona) VALUES (?, ?)", (nome, icona))
            return f"Album '{nome}' creato."
        except sqlite3.IntegrityError:
            return "Esiste già un album con questo nome."

    def aggiorna_icona_album(self, nome, icona):
        try:
            self._esegui("UPDATE Album SET Icona = ? WHERE Nome = ?", (icona, nome))
            return "Icona aggiornata."
        except Exception:
            return "Errore."

    def ottieni_lista_album(self):
        res = self._esegui("SELECT Nome, Icona FROM Album ORDER BY Nome ASC", fetch=True)
        return [[r[0], r[1]] for r in res] if res else []

    def aggiungi_foto_ad_album(self, nome_album: str, hash_foto: str) -> str:
        res = self._esegui("SELECT ID FROM Album WHERE Nome = ?", (nome_album,), fetch=True)
        if not res:
            return "Album non trovato."
        try:
            self._esegui(
                "INSERT INTO Album_Foto (Album_ID, Hash_Foto) VALUES (?, ?)",
                (res[0][0], hash_foto)
            )
            return f"Foto aggiunta a «{nome_album}»."
        except sqlite3.IntegrityError:
            return "La foto è già in questo album."

    def ottieni_foto_album(self, nome_album: str):
        return self._esegui('''
            SELECT f.Hash_Univoco, f.Nome_File, f.Data_Scatto
            FROM File f
            JOIN Album_Foto af ON f.Hash_Univoco = af.Hash_Foto
            JOIN Album a       ON af.Album_ID    = a.ID
            WHERE a.Nome = ?
            ORDER BY f.Data_Scatto ASC
        ''', (nome_album,), fetch=True)


# ══════════════════════════════════════════════════════════════════════════════
# PREDICTION ENGINE
# ══════════════════════════════════════════════════════════════════════════════
class PredictionEngine:
    WINDOW = 5
    SPEED_THRESHOLD_LOW  = 5
    SPEED_THRESHOLD_MID  = 20
    SPEED_THRESHOLD_HIGH = 50

    def __init__(self):
        self._samples: deque = deque(maxlen=self.WINDOW)
        self._lock = threading.Lock()

    def campiona(self, indice: int):
        now = time.monotonic()
        with self._lock:
            self._samples.append((indice, now))
            return self._calcola()

    def _calcola(self):
        if len(self._samples) < 2:
            return 0.0, self._samples[-1][0] if self._samples else 0, 15
        xs = [s[1] for s in self._samples]
        ys = [s[0] for s in self._samples]
        n  = len(xs)
        t0 = xs[0]
        xs = [x - t0 for x in xs]
        mean_x = sum(xs) / n
        mean_y = sum(ys) / n
        num = sum((xs[i] - mean_x) * (ys[i] - mean_y) for i in range(n))
        den = sum((xs[i] - mean_x) ** 2 for i in range(n))
        velocita = (num / den) if den > 0 else 0.0
        LOOKAHEAD = 0.4
        proiettato = int(round(ys[-1] + velocita * LOOKAHEAD))
        proiettato = max(0, proiettato)
        v_abs = abs(velocita)
        if v_abs < self.SPEED_THRESHOLD_LOW:   buffer = 15
        elif v_abs < self.SPEED_THRESHOLD_MID: buffer = 25
        elif v_abs < self.SPEED_THRESHOLD_HIGH: buffer = 35
        else: buffer = 50
        return velocita, proiettato, buffer

    def range_da_precaricare(self, indice: int, totale: int):
        velocita, proiettato, buffer = self.campiona(indice)
        scrolling_down = velocita >= 0
        start = max(0, proiettato - buffer)
        end   = min(totale - 1, proiettato + buffer)
        return start, end, scrolling_down


# ══════════════════════════════════════════════════════════════════════════════
# PREFETCH QUEUE
# ══════════════════════════════════════════════════════════════════════════════
class PrefetchQueue:
    def __init__(self, worker_fn, maxsize: int = 300):
        import queue
        self._q       = queue.PriorityQueue(maxsize=maxsize)
        self._in_volo = set()
        self._lock    = threading.Lock()
        threading.Thread(target=self._loop, args=(worker_fn,), daemon=True).start()

    def accoda(self, hash_list: list, priorita: int = 10):
        with self._lock:
            for h in hash_list:
                if h not in self._in_volo:
                    try:
                        self._q.put_nowait((priorita, h))
                        self._in_volo.add(h)
                    except Exception:
                        pass

    def segna_completato(self, h: str):
        with self._lock:
            self._in_volo.discard(h)

    def svuota(self):
        with self._lock:
            while not self._q.empty():
                try: self._q.get_nowait()
                except Exception: break
            self._in_volo.clear()

    def _loop(self, worker_fn):
        while True:
            try:
                _, h = self._q.get(timeout=1)
                worker_fn(h)
                self.segna_completato(h)
                self._q.task_done()
            except Exception:
                pass


# ══════════════════════════════════════════════════════════════════════════════
# MOTORE
# ══════════════════════════════════════════════════════════════════════════════
class MotoreAlice:
    MAX_RAM_THUMB = 200
    MAX_RAM_HD    = 8

    def __init__(self):
        self.db          = ArchivioDB(DB_PATH)
        self.ram_thumb   = OrderedDict()
        self.ram_hd      = OrderedDict()
        self._lock_thumb = threading.Lock()
        self._lock_hd    = threading.Lock()
        self._pred       = PredictionEngine()
        self._pq_thumb   = PrefetchQueue(self._worker_thumb)
        self._pq_hd      = PrefetchQueue(self._worker_hd, maxsize=20)
        self._indice_foto: list = []
        self._indice_dirty = True
        self._stream_token = 0
        self.pronto      = False

    def ottieni_miniatura(self, hash_file: str):
        # 1. Controlla se è già in RAM
        with self._lock_thumb:
            if hash_file in self.ram_thumb:
                self.ram_thumb.move_to_end(hash_file)
                return self.ram_thumb[hash_file]
                
        percorso_cache = os.path.join(CACHE_PATH, f"{hash_file}.webp")
        
        # 2. Se NON esiste su disco, la generiamo ADESSO in tempo reale!
        if not os.path.exists(percorso_cache) or os.path.getsize(percorso_cache) == 0:
            percorso_originale = self.db.ottieni_percorso_da_hash(hash_file)
            if percorso_originale and os.path.exists(percorso_originale):
                self._genera_miniatura(percorso_originale, hash_file)
            else:
                return None  # Il file originale non esiste più
                
        # 3. Ora che esiste, la leggiamo e la inviamo al frontend
        try:
            with open(percorso_cache, 'rb') as f:
                b64 = f"data:image/webp;base64,{base64.b64encode(f.read()).decode()}"
            self._cache_put_thumb(hash_file, b64)
            return b64
        except Exception:
            return None
    
    def ottieni_posizione_finestra(self):
        """Prende la posizione via Win32 API - più affidabile di pywebview."""
        if sys.platform == 'win32':
            try:
                import ctypes
                from ctypes import wintypes
                hwnd = ctypes.windll.user32.FindWindowW(None, 'Alice')
                if hwnd:
                    r = wintypes.RECT()
                    ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(r))
                    return {"x": r.left, "y": r.top}
            except:
                pass
        try:
            w = webview.windows[0]
            return {"x": w.x, "y": w.y}
        except:
            return {"x": 0, "y": 0}

    def sposta_finestra(self, x: int, y: int):
        """Sposta via Win32, con fallback a pywebview."""
        x, y = int(x), int(y)
        if sys.platform == 'win32':
            try:
                import ctypes
                hwnd = ctypes.windll.user32.FindWindowW(None, 'Alice')
                if hwnd:
                    ctypes.windll.user32.SetWindowPos(
                        hwnd, 0, x, y, 0, 0,
                        0x0001 | 0x0004  # SWP_NOSIZE | SWP_NOZORDER
                    )
                    return "ok"
            except:
                pass
        try:
            w = webview.windows[0]
            w.x = x
            w.y = y
        except:
            pass
        return "ok"

    def ottieni_miniatura_hq(self, hash_file: str):
        with self._lock_thumb:
            key = f"{hash_file}_hq"
            if key in self.ram_thumb:
                self.ram_thumb.move_to_end(key)
                return self.ram_thumb[key]
        
        # Prova prima il file HQ
        percorso = os.path.join(CACHE_PATH, f"{hash_file}_hq.webp")
        if not os.path.exists(percorso) or os.path.getsize(percorso) == 0:
            # Fallback al file LQ
            percorso = os.path.join(CACHE_PATH, f"{hash_file}.webp")
        
        if not os.path.exists(percorso) or os.path.getsize(percorso) == 0:
            # Ultimo fallback: genera miniatura dalla foto originale
            percorso_orig = self.db.ottieni_percorso_da_hash(hash_file)
            if percorso_orig and os.path.exists(percorso_orig):
                self._genera_miniatura(percorso_orig, hash_file)
                percorso = os.path.join(CACHE_PATH, f"{hash_file}_hq.webp")
                if not os.path.exists(percorso):
                    percorso = os.path.join(CACHE_PATH, f"{hash_file}.webp")
        
        if not os.path.exists(percorso) or os.path.getsize(percorso) == 0:
            return None
        
        try:
            with open(percorso, 'rb') as f:
                raw = f.read()
            if len(raw) < 100:
                return None
            b64 = f"data:image/webp;base64,{base64.b64encode(raw).decode()}"
            self._cache_put_thumb(key, b64)
            return b64
        except Exception:
            return None
        
    def ottieni_miniature_batch(self, hash_list: list) -> dict:
        """Restituisce un dizionario hash→base64 per tutte le miniature richieste."""
        risultato = {}
        for h in hash_list:
            with self._lock_thumb:
                if h in self.ram_thumb:
                    risultato[h] = self.ram_thumb[h]
                    continue
            percorso = os.path.join(CACHE_PATH, f"{h}_hq.webp")
            if not os.path.exists(percorso) or os.path.getsize(percorso) == 0:
                percorso = os.path.join(CACHE_PATH, f"{h}.webp")
            if os.path.exists(percorso) and os.path.getsize(percorso) > 0:
                try:
                    with open(percorso, 'rb') as f:
                        b64 = f"data:image/webp;base64,{base64.b64encode(f.read()).decode()}"
                    self._cache_put_thumb(h, b64)
                    risultato[h] = b64
                except Exception:
                    pass
        return risultato

    def __init__(self):
        self.db          = ArchivioDB(DB_PATH)
        self.ram_thumb   = OrderedDict()
        self.ram_hd      = OrderedDict()
        self._lock_thumb = threading.Lock()
        self._lock_hd    = threading.Lock()
        self._pred       = PredictionEngine()
        self._pq_thumb   = PrefetchQueue(self._worker_thumb)
        self._pq_hd      = PrefetchQueue(self._worker_hd, maxsize=20)
        self._indice_foto: list = []
        self._indice_dirty = True
        # Flag per interrompere lo streaming se l'utente cambia filtro
        self._stream_token = 0

    # ── INDICE ────────────────────────────────────────────────────────────────
    def _aggiorna_indice(self):
        try:
            totale = self.db.conta_foto()
            rows   = self.db.ottieni_hash_ordinati(0, totale)
            self._indice_foto  = [r[0] for r in rows]
            self._indice_dirty = False
        except Exception:
            pass

    def _get_indice(self) -> list:
        if self._indice_dirty:
            self._aggiorna_indice()
        return self._indice_foto

    # ── CACHE RAM ─────────────────────────────────────────────────────────────
    def _cache_put_thumb(self, key: str, value: str):
        with self._lock_thumb:
            self.ram_thumb[key] = value
            self.ram_thumb.move_to_end(key)
            while len(self.ram_thumb) > self.MAX_RAM_THUMB:
                self.ram_thumb.popitem(last=False)

    def _cache_put_hd(self, key: str, value: str):
        with self._lock_hd:
            self.ram_hd[key] = value
            self.ram_hd.move_to_end(key)
            while len(self.ram_hd) > self.MAX_RAM_HD:
                self.ram_hd.popitem(last=False)

    # ── WORKERS ───────────────────────────────────────────────────────────────
    def _worker_thumb(self, h: str):
        with self._lock_thumb:
            if h in self.ram_thumb: return
        percorso = os.path.join(CACHE_PATH, f"{h}.webp")
        if os.path.exists(percorso) and os.path.getsize(percorso) > 0:
            try:
                with open(percorso, 'rb') as f:
                    b64 = f"data:image/webp;base64,{base64.b64encode(f.read()).decode()}"
                self._cache_put_thumb(h, b64)
            except Exception:
                pass

    def _worker_hd(self, h: str):
        with self._lock_hd:
            if h in self.ram_hd: return
        percorso = self.db.ottieni_percorso_da_hash(h)
        if percorso and os.path.exists(percorso):
            try:
                with open(percorso, 'rb') as f:
                    raw = f.read()
                ext = os.path.splitext(percorso)[1].lower().lstrip('.')
                if ext == 'jpg': ext = 'jpeg'
                b64 = f"data:image/{ext};base64,{base64.b64encode(raw).decode()}"
                self._cache_put_hd(h, b64)
            except Exception:
                pass

    # ── HASH / EXIF / METADATI ────────────────────────────────────────────────
    @staticmethod
    def _hash_veloce(percorso: str, chunk=8192, max_bytes=1_048_576):
        hasher = hashlib.md5()
        try:
            with open(percorso, 'rb') as f:
                letti = 0
                while chunk_data := f.read(chunk):
                    hasher.update(chunk_data)
                    letti += len(chunk_data)
                    if letti >= max_bytes: break
            return hasher.hexdigest()
        except Exception:
            return None

    @staticmethod
    def _pulisci_exif(exif_dict: dict) -> dict:
        if not exif_dict: return {}
        return {
            str(ExifTags.TAGS.get(k, k)): str(v)
            for k, v in exif_dict.items()
            if not isinstance(v, bytes)
        }

    def _estrai_metadati(self, percorso: str, ext: str):
        dim_mb, data, cam, meta = 0.0, None, "Sconosciuta", "{}"
        try:
            dim_mb = round(os.path.getsize(percorso) / 1_048_576, 2)
            if ext in ('.jpg', '.jpeg', '.png'):
                with Image.open(percorso) as img:
                    raw = img._getexif()
                    if raw:
                        clean = self._pulisci_exif(raw)
                        data  = clean.get('DateTimeOriginal')
                        make  = clean.get('Make', '').strip()
                        model = clean.get('Model', '').strip()
                        if make or model: cam = f"{make} {model}".strip()
                        meta = json.dumps(clean)
        except Exception:
            pass
        if not data:
            try:
                data = datetime.fromtimestamp(os.path.getmtime(percorso)).strftime('%Y:%m:%d %H:%M:%S')
            except Exception:
                data = "Sconosciuta"
        return data, dim_mb, cam, meta

    def _genera_miniatura(self, percorso: str, hash_file: str):
        target_hq = os.path.join(CACHE_PATH, f"{hash_file}_hq.webp")
        target_lq = os.path.join(CACHE_PATH, f"{hash_file}.webp")
        try:
            with Image.open(percorso) as img:
                if img.mode not in ('RGB', 'RGBA'): img = img.convert('RGB')
                # HQ per la galleria
                if not os.path.exists(target_hq):
                    hq = img.copy()
                    hq.thumbnail((600, 600), Image.Resampling.LANCZOS)
                    hq.save(target_hq, "WEBP", quality=92, method=0)
                # LQ per la scrollbar
                if not os.path.exists(target_lq):
                    img.thumbnail((150, 150), Image.Resampling.BILINEAR)
                    img.save(target_lq, "WEBP", quality=55, method=0)
        except Exception as e:
            print(f"[Alice] Miniatura fallita: {percorso} – {e}")
            open(target_lq, 'wb').close()

    # ══════════════════════════════════════════════════════════════════════════
    # API PUBBLICA
    # ══════════════════════════════════════════════════════════════════════════

    def ottieni_miniatura(self, hash_file: str):
        with self._lock_thumb:
            if hash_file in self.ram_thumb:
                self.ram_thumb.move_to_end(hash_file)
                return self.ram_thumb[hash_file]
        percorso = os.path.join(CACHE_PATH, f"{hash_file}.webp")
        if not os.path.exists(percorso) or os.path.getsize(percorso) == 0:
            return None
        try:
            with open(percorso, 'rb') as f:
                b64 = f"data:image/webp;base64,{base64.b64encode(f.read()).decode()}"
            self._cache_put_thumb(hash_file, b64)
            return b64
        except Exception:
            return None
        
    def ottieni_foto_originale(self, hash_file: str):
        with self._lock_hd:
            if hash_file in self.ram_hd:
                self.ram_hd.move_to_end(hash_file)
                return self.ram_hd[hash_file]
        percorso = self.db.ottieni_percorso_da_hash(hash_file)
        if percorso and os.path.exists(percorso):
            try:
                with open(percorso, 'rb') as f:
                    raw = f.read()
                ext = os.path.splitext(percorso)[1].lower().lstrip('.')
                if ext == 'jpg': ext = 'jpeg'
                b64 = f"data:image/{ext};base64,{base64.b64encode(raw).decode()}"
                self._cache_put_hd(hash_file, b64)
                return b64
            except Exception:
                pass
        return None

    # ── GALLERIA COMPLETA (compatibilità) ─────────────────────────────────────
    def galleria_foto(self) -> list:
        self._indice_dirty = True
        try:
            return self.db.ottieni_tutte_le_foto()
        except Exception:
            return []

    # ── GALLERIA STREAMING ────────────────────────────────────────────────────
    def galleria_foto_count(self) -> int:
        """Restituisce il totale foto senza caricarle tutte."""
        return self.db.conta_foto()

    def galleria_foto_batch(self, offset: int, limit: int = 200) -> list:
        """
        Restituisce un batch di foto da offset a offset+limit.
        Il frontend chiama questo in loop per caricare progressivamente.
        """
        self._indice_dirty = True
        try:
            return self.db.ottieni_foto_paginata(offset, limit)
        except Exception:
            return []

    def galleria_preferiti(self) -> list:
        try:
            return self.db.ottieni_preferiti()
        except Exception:
            return []

    # ── PREDICTION ────────────────────────────────────────────────────────────
    def predizione_scroll(self, indice_corrente: int, lista_hash_visibili: list) -> str:
        # Se non è ancora pronto, ignora il carico
        if not getattr(self, 'pronto', False):
            return "ok"
            
        indice = indice_corrente
        totale = len(self._get_indice())
        if totale == 0: return "ok"
        start, end, _ = self._pred.range_da_precaricare(indice, totale)
        candidati = self._get_indice()[start:end + 1]
        centro = indice
        urgenti, speculativi = [], []
        with self._lock_thumb:
            in_ram = set(self.ram_thumb.keys())
        indice_map = {h: i for i, h in enumerate(self._get_indice())}
        for h in candidati:
            if h in in_ram or h in lista_hash_visibili: continue
            idx_h = indice_map.get(h, -1)
            if idx_h == -1: continue
            if abs(idx_h - centro) <= 10: urgenti.append(h)
            else: speculativi.append(h)
        if urgenti:     self._pq_thumb.accoda(urgenti, priorita=0)
        if speculativi: self._pq_thumb.accoda(speculativi, priorita=5)
        return "ok"

    def predizione_posizione(self, x: float, y: float,
                             indice_corrente: int,
                             elementi_per_pagina: int = 20) -> str:
        totale = len(self._get_indice())
        if totale == 0: return "ok"
        y_norm = max(0.0, min(1.0, y))
        bias   = int((y_norm - 0.5) * elementi_per_pagina)
        centro = max(0, min(totale - 1, indice_corrente + bias))
        buffer = 20
        start  = max(0, centro - buffer)
        end    = min(totale - 1, centro + buffer)
        candidati = self._get_indice()[start:end + 1]
        with self._lock_thumb:
            in_ram = set(self.ram_thumb.keys())
        with self._lock_hd:
            in_ram_hd = set(self.ram_hd.keys())
        da_caricare_thumb = [h for h in candidati if h not in in_ram]
        if da_caricare_thumb:
            self._pq_thumb.accoda(da_caricare_thumb, priorita=6)
        hd_centro = self._get_indice()[centro] if 0 <= centro < totale else None
        if hd_centro and hd_centro not in in_ram_hd:
            hd_candidati = [hd_centro]
            for offset in range(1, 4):
                if centro + offset < totale:
                    hd_candidati.append(self._get_indice()[centro + offset])
                if centro - offset >= 0:
                    hd_candidati.append(self._get_indice()[centro - offset])
            da_caricare_hd = [h for h in hd_candidati if h not in in_ram_hd]
            if da_caricare_hd:
                self._pq_hd.accoda(da_caricare_hd, priorita=2)
        return "ok"

    def precarica_in_ram(self, lista_hash: list) -> str:
        if lista_hash:
            self._pq_thumb.accoda(lista_hash, priorita=3)
        return "ok"

    def precarica_hd_in_ram(self, lista_hash: list) -> str:
        if lista_hash:
            self._pq_hd.accoda(lista_hash, priorita=0)
        return "ok"

    # ── CARTELLE ─────────────────────────────────────────────────────────────
    def ottieni_cartelle(self) -> list:
        try:
            res = self.db.ottieni_cartelle_padre()
            return [r[0] for r in res if r[0]] if res else []
        except Exception:
            return []

    def seleziona_cartella(self) -> str:
        finestra  = webview.windows[0]
        selezione = finestra.create_file_dialog(webview.FileDialog.FOLDER)
        if selezione and len(selezione) > 0:
            return self.scansiona_cartella(selezione[0])
        return "Annullato."

    def scansiona_cartella(self, percorso: str) -> str:
        EXT_VALIDELQ = {'.jpg', '.jpeg', '.png'}
        EXT_VALIDE = EXT_VALIDELQ.union({'.mp4', '.pdf', '.docx', '.psd'})
        n = 0
        try:
            import concurrent.futures
            win = webview.windows[0]
            win.evaluate_js("window._scanStart && window._scanStart()")
            
            file_list = [fp for fp in Path(percorso).rglob('*') if fp.is_file() and fp.suffix.lower() in EXT_VALIDE]
            
            def elabora_singolo_file(fp):
                h = self._hash_veloce(str(fp))
                if not h:
                    return None
                ext = fp.suffix.lower()
                data, dim, cam, meta = self._estrai_metadati(str(fp), ext)
                
                import sqlite3
                conn = sqlite3.connect(DB_PATH)
                try:
                    conn.execute('''
                        INSERT INTO File
                            (Hash_Univoco, Nome_File, Percorso_Fisico, Cartella_Padre,
                             Estensione, Data_Scatto, Dimensione_MB, Fotocamera, Metadati_Completi)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(Hash_Univoco) DO UPDATE SET
                            Percorso_Fisico = excluded.Percorso_Fisico,
                            Cartella_Padre  = excluded.Cartella_Padre
                    ''', (h, fp.name, str(fp), fp.parent.name, ext, data, dim, cam, meta))
                    conn.commit()
                except Exception:
                    pass
                finally:
                    conn.close()

                return True

            with concurrent.futures.ThreadPoolExecutor(max_workers=os.cpu_count()) as executor:
                # Utilizziamo as_completed per aggiornare il contatore ad ogni file processato
                futures = {executor.submit(elabora_singolo_file, f): f for f in file_list}
                for future in concurrent.futures.as_completed(futures):
                    res = future.result()
                    if res:
                        n += 1
                        # Aggiornamento costante dell'interfaccia con il contatore
                        win.evaluate_js(f"window._scanProgress && window._scanProgress({n})")
                
            win.evaluate_js("window._scanEnd && window._scanEnd()")
        except Exception as e:
            print(f"[Alice] Errore scansione: {e}")
        self._indice_dirty = True
        return f"{n} file indicizzati."

    def rimuovi_cartella(self, nome_cartella: str) -> str:
        conn = sqlite3.connect(DB_PATH)
        try:
            hashes = conn.execute(
                "SELECT Hash_Univoco FROM File WHERE Cartella_Padre = ?",
                (nome_cartella,)
            ).fetchall()
            for (h,) in hashes:
                tp = os.path.join(CACHE_PATH, f"{h}.webp")
                if os.path.exists(tp): os.remove(tp)
                with self._lock_thumb: self.ram_thumb.pop(h, None)
                with self._lock_hd:   self.ram_hd.pop(h, None)
            conn.execute("DELETE FROM File WHERE Cartella_Padre = ?", (nome_cartella,))
            conn.commit()
            self._indice_dirty = True
            return f"«{nome_cartella}» rimossa."
        except Exception as e:
            return f"Errore: {e}"
        finally:
            conn.close()

    def rimuovi_tutte_le_cartelle(self) -> str:
        try:
            self.db._esegui("DELETE FROM File")
            self.db._esegui("DELETE FROM Album_Foto")
            self.db._esegui("DELETE FROM Album")
            for fn in os.listdir(CACHE_PATH):
                fp = os.path.join(CACHE_PATH, fn)
                if os.path.isfile(fp): os.remove(fp)
            with self._lock_thumb: self.ram_thumb.clear()
            with self._lock_hd:   self.ram_hd.clear()
            self._pq_thumb.svuota()
            self._pq_hd.svuota()
            self._indice_dirty = True
            return "Archivio svuotato."
        except Exception as e:
            return f"Errore: {e}"

    def rescan_archivio(self) -> str:
        conn = sqlite3.connect(DB_PATH)
        try:
            tutti   = conn.execute("SELECT Percorso_Fisico FROM File").fetchall()
            rimossi = 0
            for (p,) in tutti:
                if not os.path.exists(p):
                    conn.execute("DELETE FROM File WHERE Percorso_Fisico = ?", (p,))
                    rimossi += 1
            conn.commit()
            hash_validi = {r[0] for r in conn.execute("SELECT Hash_Univoco FROM File").fetchall()}
            orfane = 0
            for fn in os.listdir(CACHE_PATH):
                h = fn.split('.')[0]
                if h not in hash_validi:
                    os.remove(os.path.join(CACHE_PATH, fn))
                    orfane += 1
            self._indice_dirty = True
            parti = []
            if rimossi: parti.append(f"{rimossi} {'foto rimossa' if rimossi == 1 else 'foto rimosse'} (file mancanti)")
            if orfane:  parti.append(f"{orfane} miniature obsolete eliminate")
            return "Sincronizzazione completata. " + (", ".join(parti) + "." if parti else "Nessuna modifica necessaria.")
        except Exception as e:
            return f"Errore: {e}"
        finally:
            conn.close()

    # ── PREFERITI ─────────────────────────────────────────────────────────────
    def imposta_preferito(self, hash_file: str, stato: bool) -> str:
        self.db.aggiorna_preferito(hash_file, stato)
        return "ok"

    # ── ALBUM ─────────────────────────────────────────────────────────────────
    def crea_album(self, nome: str, icona: str = '📁') -> str:
        return self.db.crea_album(nome, icona)

    def aggiorna_icona_album(self, nome: str, icona: str) -> str:
        return self.db.aggiorna_icona_album(nome, icona)

    def aggiungi_ad_album(self, nome_album: str, hash_foto: str) -> str:
        return self.db.aggiungi_foto_ad_album(nome_album, hash_foto)

    def ottieni_lista_album(self) -> list:
        try:   return self.db.ottieni_lista_album()
        except Exception: return []

    def ottieni_foto_album(self, nome_album: str) -> list:
        try:   return self.db.ottieni_foto_album(nome_album)
        except Exception: return []

    def rimuovi_da_album(self, nome_album: str, hash_file: str) -> str:
        try:
            self.db._esegui(
                "DELETE FROM Album_Foto WHERE Hash_Foto = ? "
                "AND Album_ID = (SELECT ID FROM Album WHERE Nome = ?)",
                (hash_file, nome_album)
            )
            return "Foto rimossa dall'album."
        except Exception as e:
            return f"Errore: {e}"

    def elimina_album(self, nome_album: str) -> str:
        try:
            self.db._esegui("DELETE FROM Album WHERE Nome = ?", (nome_album,))
            return f"Album '{nome_album}' eliminato."
        except Exception as e:
            return f"Errore: {e}"

    def ottieni_info_foto(self, hash_file: str):
        res = self.db._esegui(
            "SELECT Nome_File, Cartella_Padre, Data_Scatto, Dimensione_MB, Fotocamera "
            "FROM File WHERE Hash_Univoco = ?",
            (hash_file,), fetch=True
        )
        if res:
            return {
                "nome": res[0][0], "cartella": res[0][1], "data": res[0][2],
                "dimensione": res[0][3], "fotocamera": res[0][4]
            }
        return None

    # ── FILESYSTEM ────────────────────────────────────────────────────────────
    def apri_posizione_file(self, hash_file: str) -> str:
        percorso = self.db.ottieni_percorso_da_hash(hash_file)
        if percorso and os.path.exists(percorso):
            percorso_norm = os.path.normpath(percorso)
            try:
                if sys.platform == 'win32':
                    subprocess.Popen(f'explorer /select,"{percorso_norm}"')
                elif sys.platform == 'darwin':
                    subprocess.Popen(['open', '-R', percorso_norm])
                else:
                    subprocess.Popen(['xdg-open', os.path.dirname(percorso_norm)])
                return "File evidenziato in esplora risorse."
            except Exception as e:
                return f"Errore apertura: {e}"
        return "File originale non trovato."

    # ── FINESTRA ──────────────────────────────────────────────────────────────
    def toggle_schermo_intero(self) -> str:
        webview.windows[0].toggle_fullscreen()
        return "ok"

    def minimizza_finestra(self) -> str:
        try:
            # Sfrutta il demone nativo di pywebview per minimizzare
            webview.windows[0].minimize()
        except Exception:
            pass
        return "ok"

    def stato_database(self) -> int:
        try:   return self.db.conta_file()
        except Exception: return 0

    def esci(self):
        webview.windows[0].destroy()

    def massimizza_finestra(self) -> str:
        if sys.platform == 'win32':
            try:
                import ctypes
                hwnd = ctypes.windll.user32.FindWindowW(None, 'Alice')
                if hwnd:
                    SW_MAXIMIZE = 3
                    SW_RESTORE = 9
                    import ctypes.wintypes
                    placement = ctypes.windll.user32.IsZoomed(hwnd)
                    ctypes.windll.user32.ShowWindow(hwnd, SW_RESTORE if placement else SW_MAXIMIZE)
            except Exception:
                pass
        return "ok"
    
def abilita_taskbar_minimizza():
    if sys.platform == 'win32':
        try:
            import ctypes
            hwnd = ctypes.windll.user32.FindWindowW(None, 'Alice')
            if hwnd:
                GWL_STYLE = -16
                WS_MINIMIZEBOX = 0x00020000
                WS_THICKFRAME = 0x00040000 
                style = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_STYLE)
                ctypes.windll.user32.SetWindowLongW(hwnd, GWL_STYLE, style | WS_MINIMIZEBOX | WS_THICKFRAME)
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════════════
# AVVIO
# ══════════════════════════════════════════════════════════════════════════════
if __name__ == '__main__':
    motore   = MotoreAlice()
    finestra = webview.create_window(
        title='Alice',
        url=HTML_PATH,
        js_api=motore,
        width=1280,
        height=840,
        background_color='#1a1a1a',
        frameless=True,
        easy_drag=False,
    )
    
    finestra.events.shown += abilita_taskbar_minimizza
    
    webview.start()